﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Text.RegularExpressions;

namespace PTesteMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomeCaracter = new string[4];
            string[] semEspaco = new string[4];

            //RA: 0030482413004

            for (int i = 0; i < 4; i++)
            {
                string entrada = Interaction.InputBox($"Digite o nome {i + 1}");
                    
                if (string.IsNullOrWhiteSpace(entrada))
                {
                    MessageBox.Show("Entrada cancelada.");
                    return;
                }
              
                nomeCaracter[i] = entrada;
                string auxiliar = entrada.Replace(" ", "");

                int tamanhoNome = auxiliar.Length;

                semEspaco[i] = auxiliar;

                lstboxTamNomes.Items.Add($"O nome:{nomeCaracter[i]} tem {tamanhoNome} caracteres");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstboxTamNomes.Items.Clear();
        }

        private void frmExercicio4_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void lstboxTamNomes_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
    }
}




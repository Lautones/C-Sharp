﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExer1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1} número", "Entrada de Dados");
                
                if(auxiliar=="")
                {
                    break;
                }

                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }            
            }
            auxiliar = "";
            Array.Reverse(vetor);
            foreach (int i in vetor) 
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExer2_Click(object sender, EventArgs e)
        {
            ArrayList alunos= new ArrayList() { "Ana", "André", "Débora", "Fátima", 
                "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };

            alunos.Remove("Otávio");

            foreach (var item in alunos)
            {
                MessageBox.Show(item.ToString());
            }
           
        }

        private bool ValidarNota(string entrada, out double nota)
        {
            if (!double.TryParse(entrada, out nota))
            {
                MessageBox.Show("Valor inválido. Insira um número válido.");
                return false;
            }

            if (nota < 0 || nota > 10)
            {
                MessageBox.Show("Nota inválida. Insira uma nota entre 0 e 10.");
                return false;
            }

            return true;
        }

        private void btnExer3_Click(object sender, EventArgs e)
        {
            double[,] notaAlunos = new double[20, 3];
            double[] mediaAlunos = new double[20];

            for (int i = 0; i < 20; i++)
            {
                double soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    double nota;
                    string entrada;

                    do
                    {
                        entrada = Interaction.InputBox($"Insira a nota {j + 1} do aluno {i + 1}", "Entrada de Nota");
                    }
                    while (!ValidarNota(entrada, out nota));

                    notaAlunos[i, j] = nota;
                    soma += nota;
                }
                mediaAlunos[i] = soma / 3;
            }

            for (int i = 0; i < 20; i++)
            {
                MessageBox.Show($"Aluno {i + 1}: média: {mediaAlunos[i]}");
            }
        }

        private void btnExer4_Click(object sender, EventArgs e)
        {
            frmExercicio4 frmExercicio4=new frmExercicio4();
            frmExercicio4.ShowDialog();
        }

        private void btnExer5_Click(object sender, EventArgs e)
        {
            frmExercicio5 frmExercicio5 = new frmExercicio5();
            frmExercicio5.ShowDialog();
        }
    }

}

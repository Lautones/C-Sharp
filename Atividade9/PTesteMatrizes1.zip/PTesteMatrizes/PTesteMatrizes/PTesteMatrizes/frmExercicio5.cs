﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[,] alunosQuestoes = new string[5, 10];
            string[] gabarito = { "A", "B", "A", "C", "C", "D", "E", "B", "A", "A" };

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string entrada = Interaction.InputBox($"Digite a resposta da Questão {i + 1} do Aluno {j + 1}");

                }
            }
        }

    }
}

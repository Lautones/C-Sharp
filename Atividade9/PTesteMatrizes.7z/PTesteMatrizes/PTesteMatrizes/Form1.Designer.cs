﻿namespace PTesteMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExer1 = new System.Windows.Forms.Button();
            this.btnExer2 = new System.Windows.Forms.Button();
            this.btnExer3 = new System.Windows.Forms.Button();
            this.btnExer4 = new System.Windows.Forms.Button();
            this.btnExer5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExer1
            // 
            this.btnExer1.Location = new System.Drawing.Point(55, 116);
            this.btnExer1.Name = "btnExer1";
            this.btnExer1.Size = new System.Drawing.Size(258, 136);
            this.btnExer1.TabIndex = 0;
            this.btnExer1.Text = "Exercício 1";
            this.btnExer1.UseVisualStyleBackColor = true;
            this.btnExer1.Click += new System.EventHandler(this.btnExer1_Click);
            // 
            // btnExer2
            // 
            this.btnExer2.Location = new System.Drawing.Point(349, 116);
            this.btnExer2.Name = "btnExer2";
            this.btnExer2.Size = new System.Drawing.Size(258, 136);
            this.btnExer2.TabIndex = 0;
            this.btnExer2.Text = "Exercício 2";
            this.btnExer2.UseVisualStyleBackColor = true;
            this.btnExer2.Click += new System.EventHandler(this.btnExer2_Click);
            // 
            // btnExer3
            // 
            this.btnExer3.Location = new System.Drawing.Point(636, 116);
            this.btnExer3.Name = "btnExer3";
            this.btnExer3.Size = new System.Drawing.Size(258, 136);
            this.btnExer3.TabIndex = 0;
            this.btnExer3.Text = "Exercício 3";
            this.btnExer3.UseVisualStyleBackColor = true;
            // 
            // btnExer4
            // 
            this.btnExer4.Location = new System.Drawing.Point(55, 280);
            this.btnExer4.Name = "btnExer4";
            this.btnExer4.Size = new System.Drawing.Size(258, 136);
            this.btnExer4.TabIndex = 0;
            this.btnExer4.Text = "Exercício 4";
            this.btnExer4.UseVisualStyleBackColor = true;
            // 
            // btnExer5
            // 
            this.btnExer5.Location = new System.Drawing.Point(349, 280);
            this.btnExer5.Name = "btnExer5";
            this.btnExer5.Size = new System.Drawing.Size(258, 136);
            this.btnExer5.TabIndex = 0;
            this.btnExer5.Text = "Exercício 5";
            this.btnExer5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(948, 553);
            this.Controls.Add(this.btnExer3);
            this.Controls.Add(this.btnExer5);
            this.Controls.Add(this.btnExer2);
            this.Controls.Add(this.btnExer4);
            this.Controls.Add(this.btnExer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExer1;
        private System.Windows.Forms.Button btnExer2;
        private System.Windows.Forms.Button btnExer3;
        private System.Windows.Forms.Button btnExer4;
        private System.Windows.Forms.Button btnExer5;
    }
}


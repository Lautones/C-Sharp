﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnVerifc_Click(object sender, EventArgs e)
        {
            if(String.Compare(txtBox1.Text, txtBox2.Text, true) == 0)
            {
                MessageBox.Show("Identicos");
            }
            else
            {
                MessageBox.Show("Diferentes");
            }
        }

        private void BtnInserir1_Click(object sender, EventArgs e)
        {
            int metade = txtBox2.Text.Length/2;

            txtBox2.Text = txtBox2.Text.Substring(0, metade) + txtBox1.Text + txtBox2.Text.Substring(metade, txtBox2.Text.Length - metade);

            MessageBox.Show(txtBox2.Text);

        }

        private void BtnInserir2_Click(object sender, EventArgs e)
        {
            int metade = txtBox1.Text.Length / 2;
            txtBox2.Text = txtBox1.Text.Insert(metade, "**");
        }
    }
}

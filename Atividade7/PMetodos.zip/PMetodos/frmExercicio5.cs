﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void FrmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void BtnSorteio_Click(object sender, EventArgs e)
        {
            int numero1;
            int numero2;

            if((!int.TryParse(txtNum1.Text, out numero1) ||
                (!int.TryParse(txtNum2.Text, out numero2))))
            {

                MessageBox.Show("Preguiçoso trabalha dobrado, digite certo");
            }
            else
            {
                if( (numero1<=0) || (numero2<=0) || (numero1 >= numero2))
                {
                    MessageBox.Show("O numero 1 deve ser menor que o numero 2");
                }
                else
                {
                    Random objR = new Random();
                    int aleatorio = objR.Next(numero1,numero2); // retorna numero aleatorio 
                    MessageBox.Show($"Quem ganhou uma moto no sorteio foi: {aleatorio}");
                }
            }
        }
    }
}

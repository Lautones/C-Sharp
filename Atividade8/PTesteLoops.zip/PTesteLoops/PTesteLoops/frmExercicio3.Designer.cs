﻿namespace PTesteLoops
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxPalindrono = new System.Windows.Forms.TextBox();
            this.btnPalindrono = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtBoxPalindrono
            // 
            this.txtBoxPalindrono.Location = new System.Drawing.Point(261, 211);
            this.txtBoxPalindrono.Name = "txtBoxPalindrono";
            this.txtBoxPalindrono.Size = new System.Drawing.Size(241, 20);
            this.txtBoxPalindrono.TabIndex = 0;
            // 
            // btnPalindrono
            // 
            this.btnPalindrono.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnPalindrono.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPalindrono.ForeColor = System.Drawing.SystemColors.Desktop;
            this.btnPalindrono.Location = new System.Drawing.Point(261, 237);
            this.btnPalindrono.Name = "btnPalindrono";
            this.btnPalindrono.Size = new System.Drawing.Size(241, 46);
            this.btnPalindrono.TabIndex = 1;
            this.btnPalindrono.Text = "É um palíndrono?";
            this.btnPalindrono.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(340, 195);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Digite uma frase:";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPalindrono);
            this.Controls.Add(this.txtBoxPalindrono);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxPalindrono;
        private System.Windows.Forms.Button btnPalindrono;
        private System.Windows.Forms.Label label1;
    }
}
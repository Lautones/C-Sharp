﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            txtBox1.Clear();
            txtBox2.Clear();
            txtBox3.Clear();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();

            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtBox3.Text = resultado.ToString();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtBox3.Text = resultado.ToString();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtBox3.Text = resultado.ToString();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBox2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtBox3.Text = resultado.ToString();
            }
        }

        private void txtBox1_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtBox1.Text, out numero1))
            {
                MessageBox.Show("Número 1 Inválido");
                txtBox1.Focus();
            }
        }

        private void txtBox2_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtBox2.Text, out numero2))
            {
                MessageBox.Show("Número 2 Inválido");
                txtBox2.Focus();
            }

        }   
    }
}

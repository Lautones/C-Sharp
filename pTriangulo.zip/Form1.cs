﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        int ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtBoxA_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtBoxB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtBoxC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtBoxA_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtBoxA.Text))
            {
                MessageBox.Show("O valor não pode ser nulo ou vazio.", "Erro de validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
            else if (txtBoxA.Text == "0")
            {
                MessageBox.Show("O valor não pode ser 0", "Erro de validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        private void txtBoxB_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtBoxB.Text))
            {
                MessageBox.Show("O valor não pode ser nulo ou vazio", "Erro de validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
            else if (txtBoxB.Text == "0")
            {
                MessageBox.Show("O valor não pode ser 0", "Erro de validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        private void txtBoxA_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(txtBoxA.Text, out ladoA))
            {

            }
            else
            {
                MessageBox.Show("Por favor, digite um número A válido");
            }
        }

        private void txtBoxB_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(txtBoxB.Text, out ladoB))
            {

            }
            else
            {
                MessageBox.Show("Por favor, digite um número B válido");
            }
        }

        private void txtBoxC_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(txtBoxC.Text, out ladoC))
            {

            }
            else
            {
                MessageBox.Show("Por favor, digite um número C válido");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void txtBoxC_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtBoxC.Text))
            {
                MessageBox.Show("O valor não pode ser nulo ou vazio", "Erro de validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
            else if (txtBoxC.Text == "0")
            {
                MessageBox.Show("O valor não pode ser 0", "Erro de validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Cancel = true;
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ladoA < ladoB + ladoC) && (ladoB < ladoC + ladoA) && (ladoC < ladoA + ladoB))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    MessageBox.Show("Triângulo Isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Os lados não são válidos para formar um triângulo", "Erro de validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

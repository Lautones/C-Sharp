﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblBruto = new System.Windows.Forms.Label();
            this.lblNFilhos = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.lblDesINSS = new System.Windows.Forms.Label();
            this.txtDesINSS = new System.Windows.Forms.TextBox();
            this.lblDesIRPF = new System.Windows.Forms.Label();
            this.txtDesIRPF = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtLiquido = new System.Windows.Forms.TextBox();
            this.mskbxNome = new System.Windows.Forms.MaskedTextBox();
            this.txtBruto = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(26, 17);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(131, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do funcionário";
            // 
            // lblBruto
            // 
            this.lblBruto.AutoSize = true;
            this.lblBruto.Location = new System.Drawing.Point(26, 67);
            this.lblBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBruto.Name = "lblBruto";
            this.lblBruto.Size = new System.Drawing.Size(84, 16);
            this.lblBruto.TabIndex = 1;
            this.lblBruto.Text = "Salário Bruto";
            // 
            // lblNFilhos
            // 
            this.lblNFilhos.AutoSize = true;
            this.lblNFilhos.Location = new System.Drawing.Point(26, 115);
            this.lblNFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNFilhos.Name = "lblNFilhos";
            this.lblNFilhos.Size = new System.Drawing.Size(108, 16);
            this.lblNFilhos.TabIndex = 2;
            this.lblNFilhos.Text = "Número de filhos";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(168, 156);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(4);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(240, 55);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "VERIFICAR DESCONTO";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(174, 113);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(59, 22);
            this.numericUpDown1.TabIndex = 7;
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(24, 234);
            this.lblAliqINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(90, 16);
            this.lblAliqINSS.TabIndex = 8;
            this.lblAliqINSS.Text = "Aliquota INSS";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Location = new System.Drawing.Point(24, 282);
            this.lblAliqIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(89, 16);
            this.lblAliqIRPF.TabIndex = 9;
            this.lblAliqIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(26, 324);
            this.lblSalFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(92, 16);
            this.lblSalFamilia.TabIndex = 10;
            this.lblSalFamilia.Text = "Salário família";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(24, 364);
            this.lblSalLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(97, 16);
            this.lblSalLiquido.TabIndex = 11;
            this.lblSalLiquido.Text = "Salário Liquido";
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(168, 230);
            this.txtAliqINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(240, 22);
            this.txtAliqINSS.TabIndex = 12;
            this.txtAliqINSS.TextChanged += new System.EventHandler(this.txtAliqINSS_TextChanged);
            // 
            // lblDesINSS
            // 
            this.lblDesINSS.AutoSize = true;
            this.lblDesINSS.Location = new System.Drawing.Point(463, 232);
            this.lblDesINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesINSS.Name = "lblDesINSS";
            this.lblDesINSS.Size = new System.Drawing.Size(99, 16);
            this.lblDesINSS.TabIndex = 13;
            this.lblDesINSS.Text = "Desconto INSS";
            // 
            // txtDesINSS
            // 
            this.txtDesINSS.Enabled = false;
            this.txtDesINSS.Location = new System.Drawing.Point(591, 228);
            this.txtDesINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtDesINSS.Name = "txtDesINSS";
            this.txtDesINSS.Size = new System.Drawing.Size(240, 22);
            this.txtDesINSS.TabIndex = 14;
            // 
            // lblDesIRPF
            // 
            this.lblDesIRPF.AutoSize = true;
            this.lblDesIRPF.Location = new System.Drawing.Point(464, 276);
            this.lblDesIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDesIRPF.Name = "lblDesIRPF";
            this.lblDesIRPF.Size = new System.Drawing.Size(98, 16);
            this.lblDesIRPF.TabIndex = 15;
            this.lblDesIRPF.Text = "Desconto IRPF";
            // 
            // txtDesIRPF
            // 
            this.txtDesIRPF.Enabled = false;
            this.txtDesIRPF.Location = new System.Drawing.Point(591, 273);
            this.txtDesIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtDesIRPF.Name = "txtDesIRPF";
            this.txtDesIRPF.Size = new System.Drawing.Size(240, 22);
            this.txtDesIRPF.TabIndex = 16;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(168, 273);
            this.txtAliqIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(240, 22);
            this.txtAliqIRPF.TabIndex = 17;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(168, 320);
            this.txtSalFamilia.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(240, 22);
            this.txtSalFamilia.TabIndex = 18;
            // 
            // txtLiquido
            // 
            this.txtLiquido.Enabled = false;
            this.txtLiquido.Location = new System.Drawing.Point(168, 361);
            this.txtLiquido.Margin = new System.Windows.Forms.Padding(4);
            this.txtLiquido.Name = "txtLiquido";
            this.txtLiquido.Size = new System.Drawing.Size(240, 22);
            this.txtLiquido.TabIndex = 19;
            // 
            // mskbxNome
            // 
            this.mskbxNome.Location = new System.Drawing.Point(176, 13);
            this.mskbxNome.Margin = new System.Windows.Forms.Padding(4);
            this.mskbxNome.Name = "mskbxNome";
            this.mskbxNome.Size = new System.Drawing.Size(436, 22);
            this.mskbxNome.TabIndex = 21;
            this.mskbxNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskbxNome_KeyPress);
            // 
            // txtBruto
            // 
            this.txtBruto.Location = new System.Drawing.Point(174, 59);
            this.txtBruto.Margin = new System.Windows.Forms.Padding(4);
            this.txtBruto.Name = "txtBruto";
            this.txtBruto.Size = new System.Drawing.Size(107, 22);
            this.txtBruto.TabIndex = 22;
            this.txtBruto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBruto_KeyPress);
            this.txtBruto.Validated += new System.EventHandler(this.txtBruto_Validated);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 410);
            this.Controls.Add(this.txtBruto);
            this.Controls.Add(this.mskbxNome);
            this.Controls.Add(this.txtLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtDesIRPF);
            this.Controls.Add(this.lblDesIRPF);
            this.Controls.Add(this.txtDesINSS);
            this.Controls.Add(this.lblDesINSS);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblNFilhos);
            this.Controls.Add(this.lblBruto);
            this.Controls.Add(this.lblNome);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblBruto;
        private System.Windows.Forms.Label lblNFilhos;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.Label lblDesINSS;
        private System.Windows.Forms.TextBox txtDesINSS;
        private System.Windows.Forms.Label lblDesIRPF;
        private System.Windows.Forms.TextBox txtDesIRPF;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxNome;
        private System.Windows.Forms.TextBox txtBruto;
    }
}


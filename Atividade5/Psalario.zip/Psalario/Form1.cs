﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//3° tentativa, possível fracasso

namespace Psalario
{
    public partial class Form1 : Form
    {

        double bruto, liquido, descINSS, descIRPF, salFamilia;

        private void mskbxNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtBruto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtAliqINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBruto_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtBruto.Text, out bruto))
            {
                MessageBox.Show("Sálario inválido");
                txtBruto.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (bruto <= 800.47)
            {
                txtAliqINSS.Text = "7,65%";
                descINSS = 0.0765 * bruto;
            }
            else if (bruto <= 1050)
            {
                txtAliqINSS.Text = "8,65%";
                descINSS = 0.0865 * bruto;
            }
            else if (bruto <= 1400.77)
            {
                txtAliqINSS.Text = "9%";
                descINSS = 0.09 * bruto;
            }
            else if (bruto <= 2801.56)
            {
                txtAliqINSS.Text = "11%";
                descINSS = 0.11 * bruto;
            }
            else
            {
                txtAliqINSS.Text = "teto";
                descINSS = 308.17;
            }

            txtDesINSS.Text = descINSS.ToString();

            if (bruto <= 1257.12)
            {
                txtAliqIRPF.Text = "Isento";
            }
            else if (bruto <= 2512.08)
            {
                txtAliqIRPF.Text = "15%";
                descIRPF = 0.15 * bruto;
            }
            else
            {
                txtAliqIRPF.Text = "27,5%";
                descIRPF = 0.275 * bruto;
            }

            txtDesIRPF.Text = descIRPF.ToString();

            double filhos = Decimal.ToDouble(numericUpDown1.Value);

            if (bruto <= 435.52)
            {
                salFamilia = filhos * 22.33;
            }
            else if (bruto <= 654.61)
            {
                salFamilia = filhos * 15.74;
            }
            else
            {
                salFamilia = 0;
            }

            txtSalFamilia.Text = salFamilia.ToString();

            liquido = bruto - descINSS - descIRPF + salFamilia;
            txtLiquido.Text = liquido.ToString();
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}

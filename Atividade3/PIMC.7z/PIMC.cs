﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        Double Peso, Altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox2.Text, out Peso))
            {
                MessageBox.Show("Valor Inválido");
                textBox2.Focus();
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            IMC = Peso / (Altura * Altura);
            IMC=Math.Round(IMC,1);
            textBox3.Text = IMC.ToString();
            
                if(IMC<18.5)
              
                    MessageBox.Show("Magreza");
                    else if(IMC<24.9)
                    
                        MessageBox.Show("Normal");
                        else if (IMC<29.9)
                        
                            MessageBox.Show("Sobrepeso");
                            else if (IMC < 39.9)
                                MessageBox.Show("Obsidade");
                                else
                                                        
                                                        
                                MessageBox.Show("Obsidade Grave");
                        
                    
                
            
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox1.Text, out Peso))
            {
                MessageBox.Show("Valor Inválido");
                textBox1.Focus();
            }
        }
    }


}